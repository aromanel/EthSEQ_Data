python fastStructure/structure.py -K 4 --input=1000GP_Genotypes100s --output=1000GP_Genotypes100s --full --seed=100
python fastStructure/distruct.py -K 4 --input=1000GP_Genotypes100s --output=1000GP_Genotypes100s.svg
