python fastStructure/structure.py -K 4 --input=1000GP_Genotypes16s --output=1000GP_Genotypes16s --full --seed=100
python fastStructure/distruct.py -K 4 --input=1000GP_Genotypes16s --output=1000GP_Genotypes16s.svg
