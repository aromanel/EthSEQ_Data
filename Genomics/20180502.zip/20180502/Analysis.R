
folder = "set_path_to_downloaded_folder"
setwd(folder)

### 100 samples analysis
ethseq.coord = read.table(file.path(folder,"ethseq/100s/Report.PCAcoord"),sep="\t",as.is=T,header=T)
ethseq.report = read.table(file.path(folder,"ethseq/100s/Report.txt"),sep="\t",as.is=T,header=T)
smartpca.coord = read.table(file.path(folder,"smartpca/1000GP_Genotypes100s.pca.evec"),as.is=T)

## check samples order
all(ethseq.coord[,1]==smartpca.coord[,1])
all(ethseq.report[,1]==smartpca.coord[,1])

## plot PCA space
par(mfrow=c(2,3),mar=c(4,4,4,1))
plot(ethseq.coord$EV1,ethseq.coord$EV2,pch=19,xlab="PCA1",ylab="PCA2",main="EthSEQ")
plot(ethseq.coord$EV2,ethseq.coord$EV3,pch=19,xlab="PCA2",ylab="PCA3",main="EthSEQ")
plot(ethseq.coord$EV1,ethseq.coord$EV3,pch=19,xlab="PCA1",ylab="PCA3",main="EthSEQ")
plot(smartpca.coord[,2],smartpca.coord[,3],pch=19,xlab="PCA1",ylab="PCA2",main="SMARTPCA")
plot(smartpca.coord[,3],smartpca.coord[,4],pch=19,xlab="PCA2",ylab="PCA3",main="SMARTPCA")
plot(smartpca.coord[,2],smartpca.coord[,4],pch=19,xlab="PCA1",ylab="PCA3",main="SMARTPCA")

par(mfrow=c(1,3),mar=c(4,4,4,1))
plot(ethseq.coord$EV1,smartpca.coord[,2],pch=19,xlab="PCA1 (EthSEQ)",ylab="PCA1 (SMARTPCA)",main="EthSEQ/SMARTPCA")
plot(ethseq.coord$EV2,smartpca.coord[,3],pch=19,xlab="PCA2 (EthSEQ)",ylab="PCA2 (SMARTPCA)",main="EthSEQ/SMARTPCA")
plot(ethseq.coord$EV3,smartpca.coord[,4],pch=19,xlab="PCA3 (EthSEQ)",ylab="PCA3 (SMARTPCA)",main="EthSEQ/SMARTPCA")

## compare fastSTRUCTURE and EthSEQ report
faststructure = read.table(file.path(folder,"faststructure/1000GP_Genotypes100s.4.meanQ"),as.is=T,header=F)
ids =  read.table(file.path(folder,"faststructure/1000GP_Genotypes100s.fam"),as.is=T,header=F)
faststructure$id = ids[,2]

sel = ethseq.report$pop[which(ethseq.report$sample.id%in%faststructure[which(faststructure[,1]>=0.99),5])]
unique(sel)
sel = ethseq.report$pop[which(ethseq.report$sample.id%in%faststructure[which(faststructure[,1]<0.99),5])]
unique(sel)
