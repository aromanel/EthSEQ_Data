library(SNPRelate)
library(data.table)
library(parallel)

set.seed(666)
b = fread("/elaborazioni/sharedCO/CO_Shares/Code/ethseq/Models/1000GP/SS2.Model.50000SNPs.reference.ped",data.table=FALSE)
sif = read.table("/elaborazioni/sharedCO/CO_Shares/Code/ethseq/Models/SIF_20170208.txt",sep="\t",as.is=T,header=T)
sif = sif[which(sif$Sample%in%b[,2]),]
s = c(sample(which(sif$pop=="SAS"),100),
      sample(which(sif$pop=="AFR"),100),
      sample(which(sif$pop=="EUR"),100),
      sample(which(sif$pop=="EAS"),100))
sif = sif[s,]
b = b[which(b[,2]%in%sif$Sample),]
ped = b
map = fread("/elaborazioni/sharedCO/CO_Shares/Code/ethseq/Models/1000GP/SS2.Model.50000SNPs.map",data.table=F)
sif = read.table("/elaborazioni/sharedCO/CO_Shares/Code/ethseq/Models/SIF_20170208.txt",sep="\t",as.is=T,header=T)
vcf = fread("/elaborazioni/sharedCO/CO_Shares/Code/ethseq/VCF/1000GP/SS2.Model.50000SNPs.vcf",data.table = FALSE)

ped[1:10,1:10]
cat(all(vcf[,1]==map[,1]),"\n")
cat(all(vcf[,2]==map[,4]),"\n")
cat(all(vcf[,3]==map[,2]),"\n")
res = mclapply(7:ncol(ped),function(i)
{
  tmp = ped[,i]
  tmp[which(tmp=="1 1")] = "A A"
  tmp[which(tmp=="1 2")] = "A B"
  tmp[which(tmp=="2 2")] = "B B"
  return(tmp)
},mc.cores=3)

geno = matrix(unlist(res),nrow = length(res[[1]]),byrow = F)
ped = cbind(ped[,1:6],geno)

samples = intersect(sif$Sample,ped[,2])

ped = ped[which(ped[,2]%in%samples),]
sif = sif[which(sif$Sample%in%samples),]
all(sif$Sample==ped[,2])

idx = order(vcf$V1,vcf$V2)
vcf = vcf[idx,]
map = map[idx,]
ped = ped[,c(1:6,idx+6)]
all(vcf$V2==map$V4)

geno = ped[,7:ncol(ped)]
res = mclapply(1:ncol(geno),function(i)
{
  tmp = as.character(geno[,i])
  tmp[which(!tmp%in%c("A A","A B","B B"))] = "3"
  tmp[which(tmp=="A A")] = "0"
  tmp[which(tmp=="A B")] = "1"
  tmp[which(tmp=="B B")] = "2"
  return(as.numeric(tmp))
},mc.cores=10)

geno = matrix(as.numeric(unlist(res)),nrow = length(res[[1]]),byrow = F)

mafs = 1-apply(geno,2,function(x) (length(which(x==0))*2+length(which(x==1)))/(length(which(x!=3))*2))
idx = which(mafs>0.5)
for(i in idx)
{
  tmp = geno[,i]
  tmp[which(tmp==0)] = 4
  tmp[which(tmp==2)] = 0
  tmp[which(tmp==4)] = 2
  geno[,i] = tmp
}

snp.allele = rep("A/B",ncol(geno))
snp.allele[idx] = "B/A"

snpgdsCreateGeno("/elaborazioni/sharedCO/Home_Romanel/ReferenceModel.gds",
                 genmat = geno,
                 sample.id = ped[,2],
                 snp.id = 1:ncol(geno),
                 snp.rs.id = map[,2],
                 snp.chromosome = map[,1],
                 snp.position = map[,4],
                 snp.allele = snp.allele,
                 snpfirstdim=FALSE)

#snpgdsPED2GDS(ped.fn = "/elaborazioni/sharedCO/CO_Shares/Code/ethseq/Models/Universal.Model.ped",
#              map.fn = "/elaborazioni/sharedCO/CO_Shares/Code/ethseq/Models/Universal.Model.map",
#              out.gdsfn = "/elaborazioni/sharedCO/CO_Shares/Code/ethseq/Models/Universal.Model.gds")

genofile <- snpgdsOpen("/elaborazioni/sharedCO/Home_Romanel/ReferenceModel.gds",readonly = F)

# Add your sample annotation
#x = read.gdsn(index.gdsn(genofile, "sample.annot"))
sex = ped[,5]
unique(sex)
sex[which(sex==1)] = "M"
sex[which(sex==2)] = "F"
samp.annot <- data.frame(pop.group = sif$pop,sex = sex)
add.gdsn(genofile, "sample.annot", samp.annot,replace=T)

sign = paste(read.gdsn(index.gdsn(genofile, "snp.rs.id")),read.gdsn(index.gdsn(genofile, "snp.chromosome")),read.gdsn(index.gdsn(genofile, "snp.position")),sep="-")
sign.vcf = paste(vcf$V3,vcf$V1,vcf$V2,sep="-")
isort = match(sign,sign.vcf)
vcf = vcf[isort,]
sign.vcf = paste(vcf$V3,vcf$V1,vcf$V2,sep="-")
all(sign.vcf==sign)

add.gdsn(genofile, "snp.ref", vcf$V4)
add.gdsn(genofile, "snp.alt", vcf$V5)

snpgdsClose(genofile)


genofile <- snpgdsOpen("~/Data/Dropbox/2017_Teaching_Genomics/20170526/ethseq/ReferenceModel.gds",readonly = F)

a = fread("~/Data/Dropbox/2017_Teaching_Genomics/20170526/smartpca/1000GP_Genotypes100s.ped",data.table=FALSE)
sif = read.table("/elaborazioni/sharedCO/CO_Shares/Code/ethseq/Models/SIF_20170208.txt",sep="\t",as.is=T,header=T)
sif = sif[which(sif$Sample%in%a[,2]),]
s = c(sample(which(sif$pop=="SAS"),4),
      sample(which(sif$pop=="AFR"),4),
      sample(which(sif$pop=="EUR"),4),
      sample(which(sif$pop=="EAS"),4))
sif = sif[s,]
a = a[which(a[,2]%in%sif$Sample),]

write.table(a,"~/Data/Dropbox/2017_Teaching_Genomics/20170526/smartpca/1000GP_Genotypes16s.ped",sep="\t",quote=F,col.names=F,row.names=F)

vcf = fread("/elaborazioni/sharedCO/CO_Shares/Code/ethseq/VCF/1000GP/SS2.Model.50000SNPs.vcf",data.table = FALSE)

gt = apply(a[,7:50006],1,function(x) gsub("0 0","./.",gsub("2 2","1/1",gsub("1 2","0/1",gsub("1 1","0/0",as.character(x))))))
vcf.example = cbind(vcf,"GT",gt)

vcf.example = vcf.example[match(read.gdsn(index.gdsn(gen`ofile, "snp.rs.id")),vcf.example$V3),]
all(vcf.example$V3==read.gdsn(index.gdsn(genofile, "snp.rs.id")))

colnames(vcf.example) = c("#CHROM","POS","ID","REF","ALT","QUAL","FILTER","INFO","FORMAT",a[,2])
write.table(vcf.example,"~/Data/Dropbox/2017_Teaching_Genomics/20170526/ethseq/1000GP_Genotypes16s.vcf",sep="\t",quote=F,row.names=F,col.names=F)


res = read.table("~/Documents/Genomics/20170526/smartpca/1000GP_Genotypes.pca.evec",stringsAsFactors=F)
scatterplot3d(res[,2],res[,3],res[,4])
library(scatterplot3d)
plot(res[,2],res[,3])

library(EthSEQ)

ethseq.Analysis(
  target.vcf = "~/Data/Dropbox/2017_Teaching_Genomics/20170526/ethseq/1000GP_Genotypes.vcf",
  out.dir = "~/Data/Dropbox/2017_Teaching_Genomics/20170526/ethseq/",
  model.gds = "~/Data/Dropbox/2017_Teaching_Genomics/20170526/ethseq/ReferenceModel.gds",
  cores=1,
  verbose=TRUE,
  composite.model.call.rate = 0.99)
