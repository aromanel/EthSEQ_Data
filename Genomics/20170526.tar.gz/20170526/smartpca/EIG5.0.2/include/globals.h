#ifndef _GLOBALS_
#define _GLOBALS_

#define YES 1
#define NO  0
int numchrom = 22;
int fancynorm=YES, verbose=NO, plotmode=NO, outnum = -1 ;

#endif

